import asyncio
import fnmatch
import glob
import io
import logging
import os
import subprocess
import sys
from typing import List

import omni.repo.man

logger = logging.getLogger(__name__)


async def run_process(cmd):

    stdout = io.StringIO()
    returncode = 0
    try:
        logger.info(f"running process: {cmd}")
        proc = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=0,
        )

        async for line in proc.stdout:
            line = line.decode(errors="replace").replace("\r\n", "\n").replace("\r", "\n")
            stdout.write(line)

        await proc.wait()
        returncode = proc.returncode

    except subprocess.CalledProcessError as e:
        returncode = e.returncode

    stdout = stdout.getvalue()

    return returncode, stdout


async def gather_with_concurrency(n, tasks):
    semaphore = asyncio.Semaphore(n)

    async def sem_task(task):
        async with semaphore:
            return await task

    return await asyncio.gather(*(sem_task(task) for task in tasks))


g_files_modified = None


def get_modified_files():
    # This is an optimization so we don't check git status every time we need to investigate copyright for a file.
    # Instead we check git status at most once and cache results. If cache is primed, we return right away.
    global g_files_modified
    if g_files_modified is not None:
        return g_files_modified
    g_files_modified = set()
    git_path = omni.repo.man.find_git_path()
    p = subprocess.Popen([git_path, "status", "-s"], stdout=subprocess.PIPE, encoding="utf8")
    for f in p.stdout:
        # The short format is simply:
        # XY PATH [-> NEW_PATH]
        # where XY is a one or two letter status code. So we can simply split each line, which will either have
        # 2 elements or 4.
        elements = f.split()
        if elements[0] == "D":
            continue  # always ignore deleted files, don't format those

        if len(elements) < 4:
            filepath = elements[1]
        else:
            filepath = elements[3]
        g_files_modified.add(os.path.abspath(filepath))
    return g_files_modified


def get_all_files(root: str, files_config: dict, only_modified: bool):
    include = files_config.get("include")
    exclude = files_config.get("exclude")
    extensions = files_config.get("extensions", [])

    files = set()

    # Either take git modified files or use include/exclude patterns
    if only_modified:
        for f in get_modified_files():
            files.add(f)
    else:
        for pattern in include:
            for f in glob.glob(os.path.join(root, pattern), recursive=True):
                f = os.path.abspath(f)
                if not os.path.isfile(f):
                    continue

                subpath = os.path.relpath(f, root).replace(os.sep, "/")
                if any(fnmatch.fnmatch(subpath, p) for p in exclude):
                    continue

                files.add(f)

    # Pick only allowed file extensions
    if extensions:
        files = {f for f in files if os.path.splitext(f)[1] in extensions}

    # Make relative to the current working directory for ease or reading sake:
    cwd = os.getcwd()
    return [os.path.relpath(f, cwd) for f in files]


def teamcity_report_fail(test_id, fail_type, err):
    omni.repo.man.teamcity_message("testFailed", name=test_id, fail_type=fail_type, message=err)


def teamcity_start_test(test_id):
    omni.repo.man.teamcity_message("testStarted", name=test_id, captureStandardOutput="true")


def teamcity_stop_test(test_id):
    omni.repo.man.teamcity_message("testFinished", name=test_id)


def is_shallow_repository():
    git_path = omni.repo.man.find_git_path()
    p = subprocess.Popen([git_path, "rev-parse", "--is-shallow-repository"], stdout=subprocess.PIPE, encoding="utf8")
    for line in p.stdout:
        return line.rstrip() == "true"
    return False

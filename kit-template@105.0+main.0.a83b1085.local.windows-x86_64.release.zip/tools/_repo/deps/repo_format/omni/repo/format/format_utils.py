import datetime
import logging
import re
import subprocess
from typing import List, Optional, Tuple

import omni.repo.man

from .utils import get_modified_files

COPYRIGHT_LINE = "Copyright (c) %s, NVIDIA CORPORATION. All rights reserved."
COPYRIGHT_LINE_YEAR_RE = re.compile(
    ("[\#\/]+ " + re.escape(COPYRIGHT_LINE % "year")).replace("year", "(\d+)").replace(" ", " +")
)
COPYRIGHT_LINE_RANGE_RE = re.compile(
    ("[\#\/]+ " + re.escape(COPYRIGHT_LINE % "range")).replace("range", "(\d+)-(\d+)").replace(" ", " +")
)

LICENSE_LINES = """//
// NVIDIA CORPORATION and its licensors retain all intellectual property
// and proprietary rights in and to this software, related documentation
// and any modifications thereto. Any use, reproduction, disclosure or
// distribution of this software and related documentation without an express
// license agreement from NVIDIA CORPORATION is strictly prohibited.
//
""".splitlines()

LICENSE_TEXT = """
NVIDIA CORPORATION and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto. Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from NVIDIA CORPORATION is strictly prohibited.

"""


def _get_dates_file_was_modified(filename: str) -> List[str]:
    git_path = omni.repo.man.find_git_path()
    # First use the log to figure out the file's date history.
    p = subprocess.Popen(
        [git_path, "log", "--follow", "--format=%ad", "--date=short", filename], stdout=subprocess.PIPE, encoding="utf8"
    )
    return p.stdout


def is_file_modified(file_path: str) -> bool:
    git_path = omni.repo.man.find_git_path()
    p = subprocess.Popen([git_path, "status", "-s", file_path], stdout=subprocess.PIPE, encoding="utf8")
    for f in p.stdout:
        # The short format is simply:
        # XY PATH [-> NEW_PATH]
        # where XY is a one or two letter status code. So we can simply split each line, which will either have
        # 2 elements or 4.
        elements = f.split()
        if elements[0] != "D":  # deleted files are not considered modified - they are considered gone
            return True

    return False


def get_file_years(filename: str) -> Tuple[int, int]:
    years = []
    year_now = datetime.datetime.utcnow().year

    # First use the log to figure out the file's history.
    dates = _get_dates_file_was_modified(filename)
    for line in dates:
        years.append(int(line.split("-")[0]))

    # Next use the status of the file to figure out if it is modified, modified files are treated as being
    # changed this year.
    modified_files = get_modified_files()
    if filename in modified_files:
        years.append(year_now)

    if len(years) != 0:
        return min(years), max(years)
    else:
        return year_now, year_now


def is_shallow_repository():
    git_path = omni.repo.man.find_git_path()
    years = []
    p = subprocess.Popen([git_path, "rev-parse", "--is-shallow-repository"], stdout=subprocess.PIPE, encoding="utf8")
    for line in p.stdout:
        return line.rstrip() == "true"
    return False


def get_copyright_year_range(copyright_line: str) -> Tuple[int, int]:
    m = COPYRIGHT_LINE_YEAR_RE.match(copyright_line)
    if m:
        year = int(m.group(1))
        return year, year
    m = COPYRIGHT_LINE_RANGE_RE.match(copyright_line)
    if m:
        return int(m.group(1)), int(m.group(2))


def get_copyright_parts(text: str) -> Tuple[Optional[str], Optional[str], Optional[int], Optional[int]]:
    """This is the future, it will replace the other copyright inspection functions."""
    # At one point we had a more complicated regex for the owner group, but there isn't a way to make it robust and we
    # ultimately just need to identify the owner. Even more narrowly, we just need to know if the owner is NVIDIA or not.
    # We therefore simply capture the first *word* after the year - that's enough and it's robust. The rest is always
    # captured in postfix group, allowing full reconstruction.
    pattern = r"(?P<prefix>.*?(?=copyright))copyright +(\(c\) +)?(?P<from>[\d]{4,})-?(?P<to>[\d]{4,})?,? +(?P<owner>[A-Za-z0-9_\-]+)(?P<postfix>.*)?"
    found = re.search(pattern, text, re.IGNORECASE)
    if found:
        prefix = found["prefix"]
        owner = found["owner"].strip()
        postfix = found["postfix"]
        min_year = int(found["from"])
        if found["to"]:
            max_year = int(found["to"])
        else:
            max_year = min_year
        return prefix, postfix, min_year, max_year, owner
    else:
        return None, None, None, None, None


def get_copyright_owner_and_year_range(text: str) -> Tuple[Optional[str], Optional[int], Optional[int]]:
    pattern = r"copyright +(\(c\) +)?(?P<from>[\d]{4,})-?(?P<to>[\d]{4,})?, (?P<owner>[^.]+)"
    found = re.search(pattern, text, re.IGNORECASE)
    if found:
        owner = found["owner"].strip()
        min_year = int(found["from"])
        if found["to"]:
            max_year = int(found["to"])
        else:
            max_year = min_year
    else:
        owner = None
        min_year = max_year = None
    return owner, min_year, max_year


def is_copyright_owner_nvidia(text: str) -> bool:
    owner, from_year, to_year = get_copyright_owner_and_year_range(text)
    if owner:
        if owner.lower().startswith("nvidia"):
            return True
    return False


def generate_copyright_line(prefix: str, from_year: int, to_year: int) -> str:
    if from_year != to_year:
        years = f"{from_year}-{to_year}"
    else:
        years = f"{from_year}"
    return f"{prefix} {COPYRIGHT_LINE}" % years


def get_updated_copyright_line(path: str, copyright_line: str, content_changed: bool) -> str:
    # if the file has changed we need to make sure it has current year
    now_year = datetime.date.today().year
    if content_changed:
        to_year = now_year
    else:
        # we use git last commit year:
        _, max_year = get_file_years(path)
        to_year = max_year
    _, source_from_year, source_to_year = get_copyright_owner_and_year_range(copyright_line)
    if source_to_year != to_year:
        prefix = copyright_line.split()[0]
        # this may look wrong at first glance but take some time to think about it.
        # we can only update to the current year - because that is the year when the file will
        # now be changed in!
        copyright_line = generate_copyright_line(prefix, source_from_year, now_year)
    return copyright_line


def update_legal_statements_in_file(
    license_statement: List[str], path: str, has_changed: bool, trust_embedded_start_year: bool = False
) -> bool:
    with open(path, encoding="utf8") as original_file:
        text = original_file.read()
        new_text, modified = update_legal_statements_in_text(
            license_statement, path, has_changed, trust_embedded_start_year, text
        )
    if modified:
        with open(path, "w", encoding="utf8") as out_file:
            out_file.write(new_text)


def update_legal_statements_in_text(
    license_statement: List[str], path: str, has_changed: bool, trust_start_year_in_text: bool, text: str
) -> Tuple[str, bool]:
    comment_chars = license_statement[0].split()[0].strip()
    # Logic has been simplified from what we previously did - we first search for copyright:
    pre, post, from_year, to_year, owner = get_copyright_parts(text)
    now_year = datetime.date.today().year
    if owner is None:
        # We add copyright at top and license text
        min_y, max_y = get_file_years(path)
        # We are about to change the file so max_y needs to be now:
        max_y = now_year
        copyright_line = generate_copyright_line(comment_chars, min_y, max_y)
        new_text = copyright_line + "\n" + ("\n").join(license_statement) + "\n" + text
        return new_text, True
    elif owner.lower().startswith("nvidia"):
        is_modified = False
        # We make sure copyright is up to date and license is correct
        min_y, max_y = get_file_years(path)
        if has_changed:
            # File has already changed so current year is the upper range
            max_y = now_year
        if trust_start_year_in_text:
            min_y = from_year
        copyright_line = generate_copyright_line(comment_chars, min_y, max_y)
        out_lines = [f"{copyright_line}"]
        out_lines.extend(license_statement)
        # capture `from __future__ import` and preserve but get rid of old
        # copyright and license
        lines = text.splitlines()
        is_copyright_found = False
        is_license_section = False
        is_license_commented = True
        line_it = iter(lines)
        try:
            line = next(line_it)
            while True:
                if not is_copyright_found and "copyright" in line.lower():
                    is_copyright_found = True
                    is_license_section = True
                    line = next(line_it)
                    continue
                if is_license_section:
                    if "__license__" in line.lower() and '"""' in line:
                        is_license_commented = False
                    elif is_license_commented:
                        if not line.startswith(comment_chars):
                            is_license_section = False
                    else:
                        if line.startswith('"""'):
                            is_license_section = False
                            line = next(line_it)
                            continue
                    if is_license_section:
                        line = next(line_it)
                        continue
                out_lines.append(line)
                line = next(line_it)
        except StopIteration:
            pass
        new_text = "\n".join(out_lines)
        return new_text, (new_text != text)
    else:
        omni.repo.man.print_log(
            f"File {path!r} has copyright owned by {owner} - please exclude from formatting", logging.WARNING
        )
        # don't touch it
        return text, False

import datetime
import logging
import os
import re
import string
import subprocess
from typing import List, Optional, Tuple

import omni.repo.man

from .utils import get_modified_files, is_shallow_repository

COPYRIGHT_LINE = "Copyright (c) %s, NVIDIA CORPORATION. All rights reserved."

LICENSE_TEXT = """
NVIDIA CORPORATION and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto. Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from NVIDIA CORPORATION is strictly prohibited.

"""


def _get_dates_file_was_modified(filename: str) -> List[str]:
    git_path = omni.repo.man.find_git_path()
    # First use the log to figure out the file's date history.
    p = subprocess.Popen(
        [git_path, "log", "--follow", "--format=%ad", "--date=short", filename], stdout=subprocess.PIPE, encoding="utf8"
    )
    return p.stdout


def is_file_modified(file_path: str) -> bool:
    git_path = omni.repo.man.find_git_path()
    p = subprocess.Popen([git_path, "status", "-s", file_path], stdout=subprocess.PIPE, encoding="utf8")
    for f in p.stdout:
        # The short format is simply:
        # XY PATH [-> NEW_PATH]
        # where XY is a one or two letter status code. So we can simply split each line, which will either have
        # 2 elements or 4.
        elements = f.split()
        if elements[0] != "D":  # deleted files are not considered modified - they are considered gone
            return True

    return False


def get_file_years(filename: str) -> Tuple[int, int]:
    years = []
    year_now = datetime.datetime.utcnow().year

    # First use the log to figure out the file's history.
    dates = _get_dates_file_was_modified(filename)
    for line in dates:
        years.append(int(line.split("-")[0]))

    # Next use the status of the file to figure out if it is modified, modified files are treated as being
    # changed this year.
    modified_files = get_modified_files()
    if filename in modified_files:
        years.append(year_now)

    if len(years) != 0:
        return min(years), max(years)
    else:
        return year_now, year_now


def _get_year_from_string(string: str) -> Tuple[Optional[int], Optional[int]]:
    year_pattern = r"[^0-9]*(?P<year>\b[\d]{4}\b)"
    found = re.search(year_pattern, string)
    if found:
        return int(found["year"]), found.span()[1]
    else:
        return None, None


def get_copyright_parts(text: str) -> Tuple[Optional[str], Optional[int], Optional[int]]:
    # At one point we had a more complicated regex that was becoming a sentient being. This was hard to grok
    # and constantly evolving. So we are going with a simpler approach that is working better for the data we
    # have encountered so far.
    # Algorithm:
    # 1. Find a valid copyright statement, to be valid it must be a comment or __copyright__ statement.
    #    We've found some files that start with an empty line or "from future import" so need to support that.
    # 2. Using this line, we apply a simple regex to extract the year(s)
    # 3. With the above we can scan for the owner using the following logic:
    #    Start looking directly after "copyright" ignoring (c) and year(s) and non-alphanumerics. The first word
    #    found using this logic is the owner.

    # Test for copyright
    copyright_pattern = r"(?P<prefix>.*?(?=copyright))copyright +(\(c\) +)?"
    found = re.search(copyright_pattern, text, re.IGNORECASE)
    if found:
        # Isolate the copyright statement to a line:
        start_search = found.span()[0]
        start_ix = text.rfind("\n", 0, start_search)
        if start_ix == -1:
            start_ix = 0
        else:
            start_ix += 1
        end_ix = text.find("\n", found.span()[1])
        if end_ix == -1:
            end_ix = len(text)
        line = text[start_ix:end_ix]
        # Validate it:
        if line.startswith("#") or line.startswith("/") or line.startswith("__copyright__"):
            rest = text[found.span()[1] :]
            end_ix = rest.find("\n")
            if end_ix != -1:
                rest = rest[:end_ix]

            min_year, end_ix = _get_year_from_string(rest)
            max_year = None
            if end_ix is not None:
                rest_of_year = rest[end_ix:]
                max_year, end_ix = _get_year_from_string(rest_of_year)
                if max_year is None:
                    max_year = min_year

            # Finally look for owner:
            owner_pattern = r"([^\s]+)"
            words = re.findall(owner_pattern, rest)
            owner = None
            for word in words:
                if not word.startswith(str(min_year)):
                    owner = word.strip(string.punctuation)
                    break

            return owner, min_year, max_year

    return None, None, None


def generate_copyright_line(prefix: str, from_year: int, to_year: int) -> str:
    if from_year != to_year:
        years = f"{from_year}-{to_year}"
    else:
        years = f"{from_year}"
    return f"{prefix} {COPYRIGHT_LINE}" % years


def create_commented_license_statement(comment_chars: str, license_text: str) -> List[str]:
    lines = license_text.splitlines()
    statement = []
    for line in lines:
        if line == "":
            prefixed_line = f"{comment_chars}"
        else:
            prefixed_line = f"{comment_chars} {line}"
        statement.append(prefixed_line)
    return statement


class LegalFormatter:
    def __init__(self, comment_chars: str = "//", license_text: str = None, use_start_year_in_file: bool = True):
        self.comment_chars = comment_chars
        if license_text is None:
            license_text = LICENSE_TEXT
        self.license_statement = create_commented_license_statement(comment_chars, license_text)
        self.use_start_year_in_file = use_start_year_in_file

    def format_file(self, path: str, has_changed: bool) -> bool:
        with open(path, encoding="utf8") as original_file:
            text = original_file.read()
            new_text, modified = self.format_text(path, has_changed, text)
        if modified:
            with open(path, "w", encoding="utf8") as out_file:
                out_file.write(new_text)
        return modified

    def verify_file(self, path: str) -> bool:
        """Return True if file is already correct, otherwise False"""
        with open(path, encoding="utf8") as original_file:
            text = original_file.read()
            # `has_changed` is False because previous verify steps would otherwise prevent us from getting here
            has_changed = False
            _, modified = self.format_text(path, has_changed, text)
        return not modified

    def format_text(self, path: str, has_changed: bool, text: str) -> Tuple[str, bool]:
        # Logic has been simplified from what we previously did - we first search for copyright:
        owner, from_year, _ = get_copyright_parts(text)
        now_year = datetime.date.today().year
        if owner is None:
            # We add copyright at top and license text
            min_y, max_y = get_file_years(path)
            # We are about to change the file so max_y needs to be now:
            max_y = now_year
            copyright_line = generate_copyright_line(self.comment_chars, min_y, max_y)
            new_text = copyright_line + "\n" + ("\n").join(self.license_statement) + "\n" + text
            return new_text, True
        elif owner.lower().startswith("nvidia"):
            # We make sure copyright is up to date and license is correct
            min_y, max_y = get_file_years(path)
            if has_changed:
                # File has already changed so current year is the upper range
                max_y = now_year
            if self.use_start_year_in_file:
                min_y = from_year
            copyright_line = generate_copyright_line(self.comment_chars, min_y, max_y)
            out_lines = [
                copyright_line,
            ]
            out_lines.extend(self.license_statement)
            # capture `from __future__ import` and preserve but get rid of old
            # copyright and license
            lines = text.splitlines()
            is_copyright_found = False
            is_license_section = False
            is_license_commented = True
            line_it = iter(lines)
            try:
                line = next(line_it)
                while True:
                    if not is_copyright_found:
                        if "copyright" in line.lower():
                            is_copyright_found = True
                            is_license_section = True
                            is_license_found = False
                        # clean out any empty lines at top or advance over copyright line:
                        line = next(line_it)
                        continue
                    if is_license_section:
                        if "__license__" in line.lower() and '"""' in line:
                            is_license_commented = False
                            is_license_found = True
                        elif is_license_commented:
                            if not line.startswith(self.comment_chars):
                                is_license_section = False
                            elif is_license_found:
                                if line.strip() == self.comment_chars:
                                    is_license_section = False
                                    line = next(line_it)
                                    continue
                            else:
                                is_license_found = True
                        else:
                            if line.startswith('"""'):
                                is_license_section = False
                                line = next(line_it)
                                continue
                        if is_license_section:
                            line = next(line_it)
                            continue
                    out_lines.append(line)
                    line = next(line_it)
            except StopIteration:
                pass
            new_text = "\n".join(out_lines)
            # ensure last line is terminated by newline:
            if new_text[:-1] != "\n":
                new_text += "\n"
            # Here comes a tricky bit! The above may have modified the text; if that is the case the end year must
            # correspond to current year. Let's make sure that is the case:
            modified = new_text != text
            if modified and max_y != now_year:
                # We need to patch up the new text with the current year. We can safely assume that the first line
                # is the copyright statement - so all we need to do is to regenerate that line and splice it at the
                # front:
                copyright_line = generate_copyright_line(self.comment_chars, min_y, now_year)
                first_newline_ix = new_text.find("\n")
                new_text = copyright_line + new_text[first_newline_ix:]
            return new_text, modified
        else:
            path_universal = path.replace(os.path.sep, "/")
            omni.repo.man.print_log(
                f"File {path_universal!r} has copyright owned by {owner} - please exclude from formatting",
                logging.WARNING,
            )
            # don't touch it
            return text, False


def create_legal_formatter(tool_config: dict, lang_config: dict, comment_chars: str = "//") -> Optional[LegalFormatter]:
    # legal processing can now be enabled or disabled:
    use_legal_formatter = lang_config.get("maintain_legal_blurbs", tool_config.get("maintain_legal_blurbs", True))
    # license text can be configured
    license_text = lang_config.get("license_text", tool_config.get("license_text"))
    # by default we trust the year specified in the file
    use_start_year_from_copyright = lang_config.get(
        "use_start_year_from_copyright", tool_config.get("use_start_year_from_copyright", True)
    )

    legal_formatter = None
    if use_legal_formatter:
        if is_shallow_repository():
            # The reason we don't support this, is we use git log to determine the copyright ranges of files, in a
            # shallow repo, the history is not complete.
            omni.repo.man.print_log(
                "Cannot reliably update copyright years in shallow repositories. (ensure `variables/GIT_DEPTH` is set to 0 if you're using gitlab CI)",
                logging.ERROR,
            )
            return 1
        else:
            legal_formatter = LegalFormatter(
                comment_chars=comment_chars,
                license_text=license_text,
                use_start_year_in_file=use_start_year_from_copyright,
            )

    return legal_formatter

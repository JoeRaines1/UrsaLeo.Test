import glob
import importlib.util
import logging
import multiprocessing
import os
import platform
import subprocess
import sys
import threading
import time
from typing import List

import omni.repo.man
import packmanapi

from omni.repo.format import format_utils

from .format_utils import LICENSE_LINES
from .legal import LegalFormatter, create_legal_formatter
from .utils import get_all_files

logger = logging.getLogger(__name__)

CLANG_FORMAT_VERSIONS = {12: "12.0.1-fe237daa", 11: "11.0.0-9b831640"}

DEFAULT_CLANG_VERSION = 12

DEFAULT_CPP_FILE_PATTERNS = [
    "include/**/*.h",
    "include/**/*.hpp",
    "include/**/*.inl",
    "include/**/*.cpp",
    "include/**/*.c",
    "source/**/*.h",
    "source/**/*.hpp",
    "source/**/*.inl",
    "source/**/*.cpp",
    "source/**/*.c",
]

DEFAULT_CPP_FILE_EXCLUDE_PATTERNS = []

DEFAULT_CPP_FILE_EXTENSIONS = [".h", ".hpp", ".inl", ".cpp", ".c"]


__nvenv = None


def _get_nvenv() -> str:
    global __nvenv
    if __nvenv is None:
        deps = packmanapi.install("packagemaker", "4.0.7")
        spec = importlib.util.spec_from_file_location(
            "nvenv", os.path.join(deps["packagemaker"], "packagemaker", "nvenv", "__init__.py")
        )
        __nvenv = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(__nvenv)
    return __nvenv


def _install_clang_format(clang_version) -> str:
    clang_packman_prefix = CLANG_FORMAT_VERSIONS[clang_version]

    cfg = _get_nvenv().get_os_details()
    if cfg == "darwin-x86_64" or cfg == "darwin-arm64":
        if clang_version != 12:
            raise Exception("mac only supports clang 12")

        cfg = "macos-universal"
        clang_packman_prefix = "12.0.1-4543575a"

    deps = packmanapi.install("clang+llvm-tools", clang_packman_prefix + "-" + cfg)
    path = os.path.join("_build", cfg, "clang-tools", "bin")
    executable = "clang-format.exe" if platform.system() == "Windows" else "clang-format"
    return os.path.join(deps["clang_llvm_tools"], path, executable)


COPYRIGHT_NONE = 0
COPYRIGHT_NVIDIA = 1
COPYRIGHT_OTHER = 2


def _get_copyright_type(line):
    parts = line.split("//")
    if len(parts) == 1:
        parts = line.split("/*")

    if len(parts) > 1:
        comment = parts[1]
        if "copyright" in comment.lower():
            if "NVIDIA" in comment:
                return COPYRIGHT_NVIDIA
            else:
                return COPYRIGHT_OTHER
    return COPYRIGHT_NONE


def _verify_file(clang_format_path: str, file_path: str) -> bool:
    # First run clang-format in a mode that will give us an error code if it the formatting
    # is incorrect.
    exit_code = _run_cmd([clang_format_path, file_path, "--style=file", "--dry-run", "--Werror"])

    if exit_code:
        logger.error(f"{file_path}: Formatting is not compliant with clang-format!")
        return False

    # Now check both the license and the copyright.
    license_it = iter(LICENSE_LINES)
    is_license_being_verified = False
    is_copyright_found = False
    with open(file_path, encoding="utf8") as original_file:
        line_num = 0
        for original_line_with_newline in original_file.readlines():
            original_line = original_line_with_newline.strip("\n")
            # in order to traverse the file only once we look for copyright and license as well
            if is_license_being_verified:
                try:
                    license_line = next(license_it)
                    if original_line.replace(" ", "") != license_line.replace(" ", ""):
                        logger.error(f"{file_path} ({line_num+1}): NVIDIA License is not correct!")
                        return False
                except StopIteration:
                    is_license_being_verified = False
            res = _get_copyright_type(original_line)
            if res == COPYRIGHT_OTHER:
                logger.warning(f"{file_path} ({line_num+1}): Non-NVIDIA Copyright found in file")
                is_copyright_found = True
            elif res == COPYRIGHT_NVIDIA:
                is_copyright_found = True
                is_file_modified = format_utils.is_file_modified(file_path)
                copyright = format_utils.get_updated_copyright_line(file_path, original_line, is_file_modified)
                if copyright != original_line:
                    logger.error(f"{file_path} ({line_num+1}): NVIDIA Copyright is not correct!")
                    return False
                is_license_being_verified = True
            line_num += 1
    # If no copyright was found, indicate this an a possible issue.
    if not is_copyright_found:
        logger.warning(f"{file_path}: No copyright found in this file")

    # Finally check to see if the file ends in a new line.
    if not original_line_with_newline.endswith("\n"):
        logger.error(f"{file_path}: Missing newline at end of file")
        return False

    return True


def _create_verify_cmd(clang_format_path: str, file_path: str):
    return lambda: _verify_file(clang_format_path, file_path)


def _verify_files(clang_format_path: str, file_paths: List[str]) -> bool:
    file_paths.sort()
    cmds = [_create_verify_cmd(clang_format_path, file_path) for file_path in file_paths]
    results = _run_in_parallel(cmds)

    failed_files = 0
    for result in results:
        if not result:
            failed_files = failed_files + 1
    return failed_files


def _run_cmd(cmd):
    null_device = open(os.devnull, "w")
    proc = subprocess.Popen(cmd, stdout=null_device, stderr=subprocess.STDOUT)

    while True:
        status = proc.poll()
        if status is not None:  # Process finished
            return proc.returncode


# Like progress but no need for a pip package... Is this the best way?
class _Progress:
    def __init__(self, steps):
        self._steps = steps
        self._completed_steps = 0
        # Dictionary of in progress steps, each step creates an id, that is unregistered when it is done.
        self._in_progress = {}
        self._id_gen = 0
        self._is_atty = sys.stdout.isatty()

        self._print_lock = threading.Lock()
        self._first = False

    def _msg(self, current_msg=None):
        if self._is_atty:
            # Prints a message, assumes print lock has been taken
            columns = os.get_terminal_size().columns - 1

            if self._completed_steps == self._steps:
                msg = "Done"
            elif self._in_progress:
                msg = self._in_progress[next(iter(self._in_progress))]
            elif not current_msg is None:
                msg = current_msg
            else:
                # Protective code.
                msg = ""

            # The first part of the message is mandatory
            msg_mandated = "[" + str(self._completed_steps) + "/" + str(self._steps) + "]"
            rem = max(0, columns - (len(msg_mandated) + 1))
            if rem < len(msg) and rem > 5:
                split_len = (rem - 3) // 2
                msg = msg[:split_len] + "..." + msg[-split_len:]
            msg = msg_mandated + " " + msg
            if len(msg) < columns:
                msg = msg + (" " * (columns - len(msg)))

            sys.stdout.write("\r" + msg)
            sys.stdout.flush()
            # Force the last line out.
            if self._completed_steps == self._steps:
                print("")
        elif not current_msg is None:
            omni.repo.man.print_log(current_msg, logging.INFO)

    def start(self, msg: str):
        with self._print_lock:
            id = self._id_gen
            self._id_gen = self._id_gen + 1
            self._in_progress[id] = msg
            self._msg(msg)
            return id

    def end(self, id: int):
        with self._print_lock:
            del self._in_progress[id]
            self._completed_steps = self._completed_steps + 1
            self._msg()


# Have to spawn a seperate thread as we can deadlock on a PIPE if we don't subprocess.communicate on it and
# the PIPE is filled.
class _ParallelRunner:
    def __init__(self, cmd, sem):
        self._cmd = cmd
        self._sem = sem
        self._result = None
        self._thread = threading.Thread(target=self._run_command)
        self._thread.setDaemon(True)
        self._thread.start()

    def wait(self):
        self._thread.join()
        return self._result

    def _run_command(self):
        self._sem.acquire()
        self._result = self._cmd()
        self._sem.release()


def _run_in_parallel(cmds, cpu_count=None):
    """
    Runs the commands specified in cmds in parallel, running no more than cpu_count in parallel.
    """
    running_procs = []

    if cpu_count is None:
        cpu_count = multiprocessing.cpu_count()
    sem = threading.BoundedSemaphore(value=cpu_count)

    for cmd in cmds:
        running_procs.append(_ParallelRunner(cmd, sem))
    results = []
    for proc in running_procs:
        results.append(proc.wait())
    return results


def _compare(orig_path: str, formatted: str):
    with open(orig_path, "r", encoding="utf8") as file:
        return file.read() == formatted


def _format_file(
    clang_format_path: str,
    legal_formatter: LegalFormatter,
    path: str,
    progress=None,
    changed_list_mutex=None,
    changed_list=None,
):
    if progress:
        id = progress.start(path)

    # The -i option doesn't change the file if it didn't change use that to indicate if the
    # file changed this avoids using pipes which appears to not be idempotent between Windows
    # and Linux.
    old_time = os.path.getmtime(path)
    cmd = [clang_format_path, "-style=file", "-i", path]
    exit_code = _run_cmd(cmd)
    has_changed = os.path.getmtime(path) != old_time
    if legal_formatter:
        additional_changes = legal_formatter.format_file(path, has_changed)
    has_changed = has_changed or additional_changes

    if progress:
        progress.end(id)

    if has_changed and not changed_list_mutex is None and not changed_list is None:
        with changed_list_mutex:
            changed_list.append(path)


def _create_format_cmd(
    clang_format_path: str, legal_formatter: LegalFormatter, path: str, progress, changed_list_mutex, changed_list
):
    return lambda: _format_file(
        clang_format_path,
        legal_formatter,
        path,
        progress,
        changed_list_mutex=changed_list_mutex,
        changed_list=changed_list,
    )


def _format_files(clang_format_path: str, legal_formatter: LegalFormatter, paths: List[str], progress):
    paths.sort()
    mutex = threading.Lock()
    changed_list = []
    cmds = [
        _create_format_cmd(clang_format_path, legal_formatter, path, progress, mutex, changed_list) for path in paths
    ]
    _run_in_parallel(cmds)
    for path in changed_list:
        omni.repo.man.print_log(f"Formatted: {path}", logging.INFO)


def format_single_cpp(file: str, real_path: str = None, clang_version: int = None, repo_root: str = None) -> int:
    """Formats a single file using clang-format.

    Note this process does not do any kind of checking, and always performs the format.
    """
    # Is anybody using this function? It's drifting out of sync with the rest :(
    if clang_version is None:
        if not repo_root is None:
            # Attempt to read from the repo config
            try:
                from omni.repo.man import (
                    REPO_CONFIG_FILENAME,
                    load_toml_config_with_tokens,
                )

                config_file = os.path.join(repo_root, REPO_CONFIG_FILENAME)
                config = load_toml_config_with_tokens(repo_root, config_file)
                repo_format = config.get("repo_format", {})
                clang_version = repo_format.get("clang_version", DEFAULT_CLANG_VERSION)
            except Exception as e:
                logger.info("Couldn't determine clang version defaulting to: " + str(DEFAULT_CLANG_VERSION))
                clang_version = DEFAULT_CLANG_VERSION
        else:
            logger.info("Couldn't determine clang version defaulting to: " + str(DEFAULT_CLANG_VERSION))
            clang_version = DEFAULT_CLANG_VERSION

    legal_formatter = LegalFormatter()
    _format_file(_install_clang_format(clang_version), legal_formatter, file)

    return 0


def format_cpp(
    root: str,
    config: dict,
    verify: bool = False,
    config_file: str = None,
    modified_only: bool = False,
    force: bool = False,
    list_only: bool = False,
) -> int:
    """Format using clang format.

    Formatting timestamp is saved in `.lastformat` file to speed up sequential runs.

    For more info read `[clang-format docs] <https://clang.llvm.org/docs/ClangFormatStyleOptions.html>`__

    Args:
        root (str): Root folder path.
        verify (bool, optional): If `True` don't write the files back, just return the status. Return code 0 means nothing would change.
        config_file (str, optional): Path to your configuration file, so that the tool can check its timestamp. If config changes all files are reformatted.
        modified_only (bool): Only run clang-format on files with uncommitted changes
        force (bool): Ignore timestamp check and run clang-format on all specified files

    Returns:
        int: Return code.
    """

    tool_config = config.get("repo_format", {})
    cpp_config = tool_config.get("cpp", {})

    clang_version = cpp_config.get("clang_version", DEFAULT_CLANG_VERSION)
    clang_format_path = _install_clang_format(clang_version)

    legal_formatter = create_legal_formatter(tool_config, cpp_config)

    fileset = get_all_files(root, cpp_config.get("files", {}), modified_only)

    if not fileset:
        logger.info("No files to operate on")
        return 0

    lastrun_file = os.path.join(root, ".lastverify") if verify else os.path.join(root, ".lastformat")

    lastrun_time = 0  # effectively makes us process all files

    if os.path.isfile(lastrun_file):
        with open(lastrun_file, "r") as f:
            lastrun_time = float(f.readline())

    if config_file and os.path.getmtime(config_file) > lastrun_time:
        # this script has been modified, all files should be reprocessed
        lastrun_time = 0
    else:
        # we now check if the style file has changed (which will invalidate the lastrun_time):
        style_path = os.path.join(root, ".clang-format")
        if os.path.getmtime(style_path) > lastrun_time:
            lastrun_time = 0

    if force or verify or list_only:
        lastrun_time = 0

    # Work only on changed file
    changed_fileset = [path for path in fileset if os.path.getmtime(path) > lastrun_time]

    if list_only:
        omni.repo.man.print_log(f"[repo_format.clang] found {len(changed_fileset)} files to run.", logging.INFO)
        omni.repo.man.print_log("\n".join(changed_fileset), logging.INFO)
        return 0

    # finally we process the file list.
    if verify:
        failed_files = _verify_files(clang_format_path, changed_fileset)
        if failed_files:
            logger.error("Found %d file(s) that don't comply with our formatting rules." % failed_files)
            logger.error("** Fix this by running format_code.{sh|bat} script from the root of the repository **")
            return 1
    else:
        progress = _Progress(len(changed_fileset))
        _format_files(clang_format_path, legal_formatter, changed_fileset, progress)

    if not verify or failed_files == 0:
        if lastrun_file and lastrun_file != "<none>":
            with open(lastrun_file, "w") as f:
                f.write(str(time.time()))

    return 0

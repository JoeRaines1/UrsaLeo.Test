# Copyright 2019-2023 NVIDIA CORPORATION

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import os
import omni.ext
import omni.ui as ui
import omni.kit.quicklayout
import omni.usd
import carb.settings
from omni.kit.viewport.utility import get_active_viewport
import omni.kit.commands
import pxr.Usd as Usd

# Any class derived from `omni.ext.IExt` in top level module (defined in `python.modules` of `extension.toml`) will be
# instantiated when extension gets enabled and `on_startup(ext_id)` will be called. Later when extension gets disabled
# on_shutdown() is called.
class MyExtension(omni.ext.IExt):

    old_selected = []

    def _on_app_update_event(self, event):
        selected = omni.usd.get_context().get_selection().get_selected_prim_paths()
        cube_path = '/World/Cube'
        stage = omni.usd.get_context().get_stage()
        cube = stage.GetPrimAtPath(cube_path)
        if (cube_path in selected) and (cube_path not in self.old_selected):
            self.property_window = ui.Window("Cube Properties", width=500, height=500)
            with self.property_window.frame:
                with ui.VStack():
                    dsLabel = ui.Label("Double Sided: " + str(cube.GetAttribute('doubleSided').Get()))
                    extentLabel = ui.Label("Extent: " + str(cube.GetAttribute('extent').Get()))
                    orientationLabel = ui.Label("orientation: " + str(cube.GetAttribute('orientation').Get()))
                    colorLabel = ui.Label("Display Color: " + str(cube.GetAttribute('primvars:displayColor').Get()))
                    opacityLabel = ui.Label("Display Opacity: " + str(cube.GetAttribute('primvars:displayOpacity').Get()))
                    proxyPrimLabel = ui.Label("Proxy Prim: " + str(cube.GetRelationship('proxyPrim').GetTargets()))
                    purposeLabel = ui.Label("Purpose: " + str(cube.GetAttribute('purpose').Get()))
                    sizeLabel = ui.Label("Size: " + str(cube.GetAttribute('size').Get()))
                    visibilityLabel = ui.Label("Visibility: " + str(cube.GetAttribute('visibility').Get()))
                    oreintLabel = ui.Label("Orirent: " + str(cube.GetAttribute('xformOp:orient').Get()))
                    scaleLabel = ui.Label("Scale: " + str(cube.GetAttribute('xformOp:scale').Get()))
                    translateLabel = ui.Label("Translate: " + str(cube.GetAttribute('xformOp:translate').Get()))
                    orderLabel = ui.Label("Order: " + str(cube.GetAttribute('xformOpOrder').Get()))

        elif (cube_path not in selected) and (cube_path in self.old_selected):
            self.property_window.visible = False
        
        self.old_selected = selected

    # ext_id is current extension id. It can be used with extension manager to query additional information, like where
    # this extension is located on filesystem.
    def on_startup(self, ext_id):
        carb.settings.get_settings_interface().set("/persistent/app/viewport/displayOptions", 32255)
        file_location = os.path.realpath(__file__).split("\\extensions")[0]
        print("[omni.hello.world] MyExtension startup")
        omni.kit.quicklayout.QuickLayout.load_file(file_location + "\\apps\\data\\custom_layout.json")
        self._window = ui.Window("My Window", width=300, height=300)
        with self._window.frame:
            with ui.VStack():
                def on_click():
                    if omni.usd.get_context().get_stage() == None:
                        usd_path = file_location  + "\\apps\\data\\UrsaLeo_example.usd"
                        omni.usd.get_context().open_stage(usd_path)
                        camera_path = '/World/Left_Angle_view_Camera'
                        viewport = get_active_viewport()
                        if not viewport:
                            raise RuntimeError("No active Viewport")
                        
                        viewport.camera_path = camera_path
                        self.on_update = omni.kit.app.get_app().get_update_event_stream().create_subscription_to_pop(self._on_app_update_event)
                    
                    else: 
                        carb.settings.get_settings_interface().set("/persistent/app/viewport/displayOptions", 2255)
                    
                    button.text = "Hide Lights"

                button = ui.Button("Click me", clicked_fn=on_click)

    def on_shutdown(self):
        print("[omni.hello.world] MyExtension shutdown")

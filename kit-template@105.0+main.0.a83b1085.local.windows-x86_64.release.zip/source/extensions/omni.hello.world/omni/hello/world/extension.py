# Copyright 2019-2023 NVIDIA CORPORATION

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import os
import omni.ext
import omni.ui as ui
import pxr.Usd as usd
import omni.usd
import omni.kit.quicklayout
import omni.kit.viewport.actions.actions as actions


# Any class derived from `omni.ext.IExt` in top level module (defined in `python.modules` of `extension.toml`) will be
# instantiated when extension gets enabled and `on_startup(ext_id)` will be called. Later when extension gets disabled
# on_shutdown() is called.
class MyExtension(omni.ext.IExt):
    # ext_id is current extension id. It can be used with extension manager to query additional information, like where
    # this extension is located on filesystem.
    def on_startup(self, ext_id):
        file_location = os.path.realpath(__file__).split("\\extensions")[0]
        print("[omni.hello.world] MyExtension startup")
        omni.kit.quicklayout.QuickLayout.load_file(file_location + "\\apps\\data\\custom_layout.json")

        self._window = ui.Window("My Window", width=300, height=300)
        with self._window.frame:
            with ui.VStack():
                
                def on_click():
                    if omni.usd.get_context().get_stage() == None:
                        
                        usd_path = file_location  + "\\apps\\data\\UrsaLeo_example.usd"
                        omni.usd.get_context().open_stage(usd_path)
                    else: 
                        actions.toggle_light_visibility(False)
                    button.text = "Hide Lights"

                button = ui.Button("Click me", clicked_fn=on_click)

    def on_shutdown(self):
        print("[omni.hello.world] MyExtension shutdown")
